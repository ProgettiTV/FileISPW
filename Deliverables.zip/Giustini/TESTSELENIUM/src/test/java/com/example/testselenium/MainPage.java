package com.example.testselenium;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.text.SimpleDateFormat;
import java.util.Date;




public class MainPage {

    public static void main(String[] args) throws InterruptedException {
            System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");
            WebDriver driver = new ChromeDriver();
            driver.get("https://www.google.com/search?q=euro+to+yen&oq=euro+to+yen&aqs=chrome.0.35i39l2j0l4j46j69i60.4129j1j7&sourceid=chrome&ie=UTF-8");

            SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
            for (int i = 0; i < 5; i++) {
                WebElement exchangeRate = driver.findElement(By.xpath("//*[@id='knowledge-currency__updatable-data-column']/div[1]"));
                System.out.println("Ora: " + formatter.format(new Date()) + " Valore attuale dell'euro: " + exchangeRate.getText());
                Thread.sleep(10000);
            }

            driver.quit();
        }
    }
    